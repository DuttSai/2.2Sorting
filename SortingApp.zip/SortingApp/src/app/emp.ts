export class Emp {
    id:number
    empName:string
    empSal:number
    empDep:string
}
